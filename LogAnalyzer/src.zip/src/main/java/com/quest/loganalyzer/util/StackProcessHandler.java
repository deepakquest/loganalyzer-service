package com.quest.loganalyzer.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class StackProcessHandler{
// my first thread
public static Thread esThread = new Thread(){
     public void run(){
    	 startES();
     }
 };

// my second thread
public static Thread lsThread = new Thread(){
     public void run(){
    	 startLogstash();
     }
 };
 
	public static void startLogstash() {
		try {
			ProcessBuilder pb = new ProcessBuilder("cmd", "/c",
					"D:\\LA\\ELK\\logstash-7.0.0\\bin\\logstash.bat -f D:\\LA\\ELK\\logstash-7.0.0\\bin\\logstashModality-filter.conf");
			Process process = pb.start();
			System.out.println("Alive : " + process.isAlive());
			BufferedReader stdInput = new BufferedReader(new InputStreamReader(process.getInputStream()));
			String s;
			while ((s = stdInput.readLine()) != null) {
				System.out.println(s);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public static void startES() {
		try {
			ProcessBuilder esPB = new ProcessBuilder("cmd", "/c",
					"D:\\LA\\ELK\\elasticsearch-7.0.0\\bin\\elasticsearch.bat");
			Process esProcess = esPB.start();
			System.out.println("ElasticSearch started : " + esProcess.isAlive());
			BufferedReader stdInput = new BufferedReader(new InputStreamReader(esProcess.getInputStream()));
			String s;
			while ((s = stdInput.readLine()) != null) {
				System.out.println(s);
				/*
				 * if (s.endsWith("Successfully started Logstash API endpoint {:port=>9600}")) {
				 * System.out.println("one"); System.setProperty("elasticsearch.startup",
				 * "true"); } else if (s.endsWith("Connection refused: connect\"}")) {
				 * System.out.println("two"); System.setProperty("elasticsearch.startup",
				 * "true"); }
				 */
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
 
}

