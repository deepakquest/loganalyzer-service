package com.quest.loganalyzer;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;

import com.quest.loganalyzer.service.LogsService;
import com.quest.loganalyzer.util.ElasticServer;
import com.quest.loganalyzer.util.LogStashServer;
import com.quest.loganalyzer.util.StackProcessHandler;

@SpringBootApplication(scanBasePackages = { "com.quest.loganalyzer" }) // same as @Configuration
																		// @EnableAutoConfiguration @ComponentScan
																		// combined
@EnableConfigurationProperties({ FileStorageProperties.class })
public class SpringBootRestApiApp {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootRestApiApp.class, args);

		/*
		 * StackProcessHandler.lsThread.start();
		 * 
		 * try { TimeUnit.MINUTES.sleep(1); } catch (InterruptedException e) {
		 * e.printStackTrace(); } StackProcessHandler.esThread.start();
		 */

		// sp.startELStack();

		ElasticServer esServer = ElasticServer.getInstance();
		LogStashServer lsServer = LogStashServer.getInstance();
		Thread t1 = new Thread(esServer, "T1");
		t1.start();
		try {
			TimeUnit.SECONDS.sleep(50);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		Thread t2 = new Thread(lsServer, "T2");
		t2.start();
		//StackProcessHandler.lsThread = new Thread(lsServer, "T2");
		//StackProcessHandler.lsThread.start();

	}

}
