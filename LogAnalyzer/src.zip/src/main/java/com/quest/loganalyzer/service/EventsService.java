package com.quest.loganalyzer.service;

import java.util.List;

import org.json.simple.parser.ParseException;

import com.quest.loganalyzer.model.LogEntry;
import com.quest.loganalyzer.model.User;

public interface EventsService {

	User findById(long id);

	User findByName(String name);

	void saveUser(User user);

	void updateUser(User user);

	void deleteUserById(long id);

	List<LogEntry> findAllUsers();

	void deleteAllUsers();

	boolean isUserExist(User user);

	List<LogEntry> queryES(String keyword) throws ParseException;

}
