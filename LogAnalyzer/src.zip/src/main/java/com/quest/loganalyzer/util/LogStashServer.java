package com.quest.loganalyzer.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import com.quest.loganalyzer.util.LogStashServer;

public class LogStashServer implements Runnable {
	private boolean exit = false;
	Process process = null;
	private static LogStashServer single_instance = null;

	private LogStashServer() {

	}

	public static LogStashServer getInstance() {
		if (single_instance == null)
			single_instance = new LogStashServer();

		return single_instance;
	}

	public void run() {

		while (keepRunning()) {
			System.out.println("LSServer is running.....");
			startLogstash();
		}
		System.out.println("LSServer is stopped....");
	}

	public synchronized void stop() {
		process.destroy();
		System.out.println("LSServer is stopping.....");
		this.exit = true;
	}

	private synchronized boolean keepRunning() {
		return this.exit == false;
	}

	public void startLogstash() {
		try {
			ProcessBuilder pb = new ProcessBuilder("cmd", "/c",
					"D:\\LA\\ELK\\logstash-7.0.0\\bin\\logstash.bat -f D:\\LA\\ELK\\logstash-7.0.0\\bin\\logstashModality-filter.conf");
			process = pb.start();
			System.out.println("Logstash started : " + process.isAlive());
			BufferedReader stdInput = new BufferedReader(new InputStreamReader(process.getInputStream()));
			String s;
			while ((s = stdInput.readLine()) != null) {
				System.out.println(s);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}