package com.quest.loganalyzer.service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import com.quest.loganalyzer.FileStorageProperties;

@Service("logsService")
public class LogsServiceImpl implements LogsService {

	//private static List<LogEntry> logEntries;
	private Path fileStorageLocation = null;

	/*
	 * public List<User> findAllUsers() { return users; }
	 */
	@Autowired
	public LogsServiceImpl(FileStorageProperties fileStorageProperties) {
		this.fileStorageLocation = Paths.get(fileStorageProperties.getUploadDir()).toAbsolutePath().normalize();

		try {
			Files.createDirectories(this.fileStorageLocation);
		} catch (Exception ex) {
			System.out.println("Could not create the directory where the uploaded files will be stored.");
		}
	}

	/**
	 * reload configuration for logstash.
	 */
	public void reloadLogstash() {

		stopLogstash();
		try {
			ProcessBuilder pb = new ProcessBuilder("cmd", "/c",
					"D:\\LA\\ELK\\logstash-7.0.0\\bin\\logstash.bat -f D:\\LA\\ELK\\logstash-7.0.0\\bin\\logstashModality-filter.conf --config.reload.automatic");
			Process process = pb.start();
			System.out.println("LStash Reload : " + process.isAlive());
			BufferedReader stdInput = new BufferedReader(new InputStreamReader(process.getInputStream()));
			String s;
			while ((s = stdInput.readLine()) != null) {
				System.out.println(s);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void stopLogstash() {
		try {
			ProcessBuilder pb = new ProcessBuilder("cmd", "/c",
					"taskkill /im java.exe");
			Process process = pb.start();
			System.out.println("LStash stop : " + process.isAlive());
			BufferedReader stdInput = new BufferedReader(new InputStreamReader(process.getInputStream()));
			String s;
			while ((s = stdInput.readLine()) != null) {
				System.out.println(s);
			}
			try {
				TimeUnit.SECONDS.sleep(20);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			process.destroy();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	public String storeFile(MultipartFile file) throws Exception {
		// Normalize file name
		String fileName = StringUtils.cleanPath(file.getOriginalFilename());

		try {
			// Check if the file's name contains invalid characters
			if (fileName.contains("..")) {
				throw new Exception("Sorry! Filename contains invalid path sequence " + fileName);
			}

			// Copy file to the target location (Replacing existing file with the same name)
			Path targetLocation = this.fileStorageLocation.resolve(fileName);
			Files.copy(file.getInputStream(), targetLocation, StandardCopyOption.REPLACE_EXISTING);

			return fileName;
		} catch (Exception ex) {
			throw new Exception("Could not store file " + fileName + ". Please try again!", ex);
		}
	}

	public void appendFileToConfig(String filename) throws IOException {
		Path path = Paths.get("D:\\LA\\ELK\\logstash-7.0.0\\bin\\logstashModality-filter.conf");
		List<String> fileContent = new ArrayList<>(Files.readAllLines(path, StandardCharsets.UTF_8));
		String newPath = "    path => \"D:/LA/ELK/logstashinput/" + filename + "\"";
		System.out.println("path : " + newPath);
		for (int i = 0; i < fileContent.size(); i++) {
			if (fileContent.get(i).equals("    path => \"D:/LA/ELK/initfolder/u2d.0.0.txt\"")) {
				System.out.println("gotit");
				fileContent.set(i, newPath);
				break;
			}
		}
		Files.write(path, fileContent, StandardCharsets.UTF_8);
	}

}
