package com.quest.loganalyzer.controller;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.quest.loganalyzer.service.LogsService;

@RestController
@RequestMapping("/api")
public class LogsController {

	public static final Logger logger = LoggerFactory.getLogger(LogsController.class);

	@Autowired
	LogsService logsService;

	// http://localhost:8080/loganalyzer/api/logs

	/*
	 * @RequestMapping(value = "/logs", method = RequestMethod.GET) public
	 * ResponseEntity<?> uploadAndStart() { logsService.runLogstash(); return new
	 * ResponseEntity<String>(HttpStatus.OK); }
	 */

	@RequestMapping(value = "/logs", method = RequestMethod.POST)
	public ResponseEntity<String> uploadMultipleFiles(@RequestParam("filenames") String[] filenames,
			@RequestParam("modality") String modality) {
		System.out.println("Upload success");
		String filename = null;
		if (filenames.length > 1) {
			filename = "*";
		} else {
			filename = filenames[0];
		}
		
		try {
			logsService.appendFileToConfig(filename);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return new ResponseEntity<String>("Success",HttpStatus.CREATED);
	}


	/*
	 * @RequestMapping(value = "/logs", method = RequestMethod.POST) public
	 * ResponseEntity<List<UploadFileResponse>>
	 * uploadMultipleFiles(@RequestParam("files") MultipartFile[] files,
	 * 
	 * @RequestParam("modality") String modality) {
	 * System.out.println("Upload success"); String filename = null; if
	 * (files.length > 1) { filename = "*"; } else { filename =
	 * files[0].getOriginalFilename(); } ResponseEntity<List<UploadFileResponse>>
	 * response = new ResponseEntity<List<UploadFileResponse>>(
	 * Arrays.asList(files).stream().map(file ->
	 * uploadFile(file)).collect(Collectors.toList()), HttpStatus.CREATED); return
	 * response; }
	 * 
	 * @PostMapping("/uploadFile") public UploadFileResponse
	 * uploadFile(@RequestParam("file") MultipartFile file) { String fileName =
	 * null;
	 * 
	 * try { fileName = logsService.storeFile(file); } catch (Exception e) {
	 * e.printStackTrace(); }
	 * 
	 * return new UploadFileResponse(fileName, file.getContentType(),
	 * file.getSize()); }
	 */

}