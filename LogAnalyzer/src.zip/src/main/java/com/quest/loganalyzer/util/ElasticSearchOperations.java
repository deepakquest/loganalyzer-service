package com.quest.loganalyzer.util;

import java.io.IOException;

import org.apache.http.HttpHost;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestClient;
import org.elasticsearch.client.RestClientBuilder;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.common.unit.Fuzziness;
import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.SearchHits;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.json.simple.parser.ParseException;

public class ElasticSearchOperations {

	@SuppressWarnings("resource")
	public static SearchHit[] searchCall() throws ParseException {
		System.out.println("searchCall");
		RestClientBuilder builder = RestClient.builder(new HttpHost("localhost", 9200, "http"));
		RestHighLevelClient client = new RestHighLevelClient(builder);

		SearchRequest searchRequest = new SearchRequest("logsindexnew");
		SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();

		searchSourceBuilder.query(QueryBuilders.matchAllQuery());
		searchRequest.source(searchSourceBuilder);
		SearchResponse searchResponse = null;

		try {
			searchResponse = client.search(searchRequest, RequestOptions.DEFAULT);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("sr0-----" + searchResponse.toString());
		SearchHits hits = searchResponse.getHits();
		System.out.println("sr1-----" + hits.toString());
		SearchHit[] searchHits = hits.getHits();
		return searchHits;
	}

	public static SearchHit[] searchCall(String keyword) throws ParseException {
		System.out.println("searchCall");
		RestClientBuilder builder = RestClient.builder(new HttpHost("localhost", 9200, "http"));
		RestHighLevelClient client = new RestHighLevelClient(builder);

		SearchRequest searchRequest = new SearchRequest("logsindexnew");
		SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();
		QueryBuilder matchQueryBuilder;
		// Checks if keyword is null or empty
		if (keyword.equals(null) || keyword.equals("") ||  keyword.length() == 0) {
			matchQueryBuilder = QueryBuilders.matchAllQuery();
			System.out.println("String:" + keyword);
		} else {

			matchQueryBuilder = QueryBuilders.matchQuery("message", keyword).fuzziness(Fuzziness.AUTO).prefixLength(3)
					.maxExpansions(100);
			System.out.println("Stringin:" + keyword);
		}

		// searchSourceBuilder.query(QueryBuilders.matchAllQuery());
		searchSourceBuilder.query(matchQueryBuilder);
		searchRequest.source(searchSourceBuilder);
		SearchResponse searchResponse = null;

		try {
			searchResponse = client.search(searchRequest, RequestOptions.DEFAULT);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("sr0-----" + searchResponse.toString());
		SearchHits hits = searchResponse.getHits();
		System.out.println("sr1-----" + hits.toString());
		SearchHit[] searchHits = hits.getHits();
		try {
			client.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return searchHits;
	}
}
