package com.quest.loganalyzer.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class ElasticServer implements Runnable {
	private volatile boolean exit = false;

	private static ElasticServer single_instance = null; 
	
	private ElasticServer() {
		
	}
    public static ElasticServer getInstance() 
    { 
        if (single_instance == null) 
            single_instance = new ElasticServer(); 
  
        return single_instance; 
    }
	
	public void run() {
		while (!exit) {
			System.out.println("ESServer is running.....");
			startES();
		}

		System.out.println("ESServer is stopped....");
	}

	public void stop() {
		exit = true;
	}

	public static void startES() {
		try {
			ProcessBuilder esPB = new ProcessBuilder("cmd", "/c",
					"D:\\LA\\ELK\\elasticsearch-7.0.0\\bin\\elasticsearch.bat");
			Process esProcess = esPB.start();
			System.out.println("ElasticSearch started : " + esProcess.isAlive());
			BufferedReader stdInput = new BufferedReader(new InputStreamReader(esProcess.getInputStream()));
			String s;
			while ((s = stdInput.readLine()) != null) {
				System.out.println(s);
				/*
				 * if (s.endsWith("Successfully started Logstash API endpoint {:port=>9600}")) {
				 * System.out.println("one"); System.setProperty("elasticsearch.startup",
				 * "true"); } else if (s.endsWith("Connection refused: connect\"}")) {
				 * System.out.println("two"); System.setProperty("elasticsearch.startup",
				 * "true"); }
				 */
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}