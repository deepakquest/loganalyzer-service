package com.quest.loganalyzer.service;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.elasticsearch.search.SearchHit;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.stereotype.Service;

import com.quest.loganalyzer.model.LogEntry;
import com.quest.loganalyzer.model.User;
import com.quest.loganalyzer.util.ElasticSearchOperations;

@Service("eventsService")
public class EventsServiceImpl implements EventsService {

	private static final AtomicLong counter = new AtomicLong();

	private static List<User> users;

	/*
	 * public List<User> findAllUsers() { return users; }
	 */

	public List<LogEntry> getElasticOutputoLD() {
		File file = getFileFromResources("testjsonfile.txt");
		JSONParser parser = new JSONParser();
		try {
			printFile1(file);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Object obj = null;
		try {
			obj = parser.parse(new FileReader(file));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		JSONArray logEntriesJSON = (JSONArray) obj;
		// JSONObject jsonObject = (JSONObject) obj;
		@SuppressWarnings("unchecked")
		Iterator<JSONObject> iterator = logEntriesJSON.iterator();
		List<LogEntry> logEntries = new ArrayList<LogEntry>();
		while (iterator.hasNext()) {
			// System.out.println(iterator.next());
			JSONObject jsonObject = (JSONObject) iterator.next();
			String logName = (String) jsonObject.get("logname");
			String logLevel = (String) jsonObject.get("LOGLEVEL:loglevel");
			String date = (String) jsonObject.get("@timestamp");
			String time = (String) jsonObject.get("TIME");
			String message = (String) jsonObject.get("GREEDYDATA:messagepart");
			String fullMessage = (String) jsonObject.get("message");
			LogEntry logentry = new LogEntry(logName, logLevel, date, time, message, fullMessage);
			System.out.println("Data : " + logentry.toString());
			logEntries.add(logentry);
		}

		return logEntries;
	}

	public List<LogEntry> queryES(String keyword) {
		JSONObject jsonObject = new JSONObject();
		List<LogEntry> logEntries = new ArrayList<LogEntry>();
		JSONParser parser = new JSONParser();
		SearchHit[] searchHits;
		Pattern p = Pattern.compile("^(?:\\w+\\s+){3}([^\\n\\r]+)$");

		try {
			searchHits = ElasticSearchOperations.searchCall(keyword);
			for (SearchHit hit : searchHits) {
				jsonObject = (JSONObject) parser.parse(hit.getSourceAsString());
				String logName = (String) jsonObject.get("type");
				String logLevel = (String) jsonObject.get("level");
				System.out.println("Date: " + (String) jsonObject.get("logdate"));
				String date = (String) jsonObject.get("logdate");
				String time = "";
				if (date == null) {
					date = "";
				} else {
					Matcher m = p.matcher(date);
					if (m.find()) {
						time = m.group(1);
					}
				}

				String message = (String) jsonObject.get("errormsg");
				String fullMessage = (String) jsonObject.get("message");
				LogEntry logentry = new LogEntry(logName, logLevel, date, time, message, fullMessage);
				System.out.println("Data : " + logentry.toString());
				logEntries.add(logentry);
			}
		} catch (ParseException e) {
			e.printStackTrace();
		}

		return logEntries;
	}

	// get file from classpath, resources folder
	private File getFileFromResources(String fileName) {

		ClassLoader classLoader = getClass().getClassLoader();

		URL resource = classLoader.getResource(fileName);
		if (resource == null) {
			throw new IllegalArgumentException("file is not found!");
		} else {
			return new File(resource.getFile());
		}

	}

	private void printFile1(File file) throws IOException {

		if (file == null)
			return;

		try (FileReader reader = new FileReader(file); BufferedReader br = new BufferedReader(reader)) {

			String line;
			while ((line = br.readLine()) != null) {
				System.out.println(line);
			}
		}
	}

	public User findById(long id) {
		for (User user : users) {
			if (user.getId() == id) {
				return user;
			}
		}
		return null;
	}

	public User findByName(String name) {
		for (User user : users) {
			if (user.getName().equalsIgnoreCase(name)) {
				return user;
			}
		}
		return null;
	}

	public void saveUser(User user) {
		user.setId(counter.incrementAndGet());
		users.add(user);
	}

	public void updateUser(User user) {
		int index = users.indexOf(user);
		users.set(index, user);
	}

	public void deleteUserById(long id) {

		for (Iterator<User> iterator = users.iterator(); iterator.hasNext();) {
			User user = iterator.next();
			if (user.getId() == id) {
				iterator.remove();
			}
		}
	}

	public boolean isUserExist(User user) {
		return findByName(user.getName()) != null;
	}

	public void deleteAllUsers() {
		users.clear();
	}

	/*
	 * private static List<User> populateDummyUsers() { List<User> users = new
	 * ArrayList<User>(); users.add(new User(counter.incrementAndGet(), "Sam", 30,
	 * 70000)); users.add(new User(counter.incrementAndGet(), "Tom", 40, 50000));
	 * users.add(new User(counter.incrementAndGet(), "Jerome", 45, 30000));
	 * users.add(new User(counter.incrementAndGet(), "Silvia", 50, 40000)); return
	 * users; }
	 */
	@Override
	public List<LogEntry> findAllUsers() {
		// TODO Auto-generated method stub
		return null;
	}

}
