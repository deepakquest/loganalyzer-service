package com.quest.loganalyzer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;

@PropertySource("classpath:application.properties")
//@ConfigurationProperties(prefix = "path")
public class PathProperties {

	@Autowired
	private Environment env;

	private static String elasticPath;
	private static String logstashPath;

	public String getLogstashPath() {
		return env.getProperty("logstash.app.path");
	}

	public String getElasticPath() {
		return env.getProperty("elastic.app.path");
	}
}