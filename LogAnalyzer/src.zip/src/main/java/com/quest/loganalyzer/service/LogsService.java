package com.quest.loganalyzer.service;

import java.io.IOException;

import org.springframework.web.multipart.MultipartFile;

public interface LogsService {

	String storeFile(MultipartFile file) throws Exception;

	void appendFileToConfig(String filename) throws IOException;

	void reloadLogstash();

}
