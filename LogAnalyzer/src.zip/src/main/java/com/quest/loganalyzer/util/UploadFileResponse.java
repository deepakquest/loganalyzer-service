package com.quest.loganalyzer.util;

import java.io.Serializable;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;


@JsonSerialize
public class UploadFileResponse {
    private String fileName;
    private String fileDownloadUri;
    private String fileType;
    private long size;

    public UploadFileResponse(String fileName, String fileType, long size) {
        this.fileName = fileName;
        this.fileType = fileType;
        this.size = size;
    }
}
